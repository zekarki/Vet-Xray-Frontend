import React, { useEffect, useState } from 'react';
import './AdminPanel.css';

interface User {
  id: number;
  first_name: string;
  student_id: string;
  is_staff: boolean;
}

interface Patient {
  patient_id: string;
  name: string;
  species: string;
  owner: string;
  owner_phone: string;
  breed: string;
  chip_no: string;
  date_of_birth: string;
  sex: string;
}

const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);

  useEffect(() => {
    fetchUsers();
    fetchPatients();
  }, []);

  const fetchUsers = async () => {
  try {
    console.log("Fetching users...");
    const response = await fetch('http://localhost:8000/user/', {
      method: 'GET',
      credentials: 'include',
    });
    const data = await response.json();
    console.log("Users response:", data);
    if (response.ok && data.users) {
      setUsers(data.users);
    }
  } catch (err) {
    console.error('Error fetching users:', err);
  }
};

const fetchPatients = async () => {
  try {
    console.log("Fetching patients...");
    const response = await fetch('http://localhost:8000/patient/', {
      method: 'GET',
      credentials: 'include',
    });
    const data = await response.json();
    console.log("Patients response:", data);
    if (response.ok && data.patients) {
      setPatients(data.patients);
    }
  } catch (err) {
    console.error('Error fetching patients:', err);
  }
};

  const deleteUser = async (student_id: string) => {
  const confirmed = window.confirm(`Delete user ${student_id}?`);
  if (!confirmed) return;

  try {
    const response = await fetch('http://localhost:8000/user/', {
      method: 'DELETE',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ student_id })
    });
    const data = await response.json();
    console.log('User delete response:', data);
    fetchUsers();
  } catch (err) {
    console.error('Failed to delete user:', err);
  }
};


  const deletePatient = async (patient_id: string) => {
  const confirmed = window.confirm(`Delete patient ${patient_id}?`);
  if (!confirmed) return;

  try {
    const response = await fetch('http://localhost:8000/patient/', {
      method: 'DELETE',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ patient_id })
    });
    const data = await response.json();
    console.log('Patient delete response:', data);
    fetchPatients();
  } catch (err) {
    console.error('Failed to delete patient:', err);
  }
};


  return (
    <div className="admin-panel-grid">
      <div className="admin-section">
        <h2>Manage Users</h2>
        {users.map(user => (
          <div key={user.student_id} className="admin-card">
            <div><strong>{user.first_name}</strong> — {user.student_id}</div>
            <div>Role: {user.is_staff ? 'Teacher' : 'Student'}</div>
            <button onClick={() => deleteUser(user.student_id)} className="delete-btn">Delete</button>
          </div>
        ))}
      </div>

      <div className="admin-section">
        <h2>Manage Patients</h2>
        {patients.map(patient => (
          <div key={patient.patient_id} className="admin-card">
            <div><strong>{patient.name}</strong> — {patient.species}</div>
            <div>Owner: {patient.owner} | Phone: {patient.owner_phone}</div>
            <button onClick={() => deletePatient(patient.patient_id)} className="delete-btn">Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminPanel;
