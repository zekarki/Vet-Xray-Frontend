import React, { useState } from 'react';
import './MainPage.css';
import Silhouette from './Silhouette';
import PatientInfo from './PatientInfo';
import PatientList from './PatientList';

const animals = ['Dog', 'Cat', 'Horse', 'Rabbit'];

const MainPage: React.FC = () => {
  const [selectedAnimal, setSelectedAnimal] = useState<string>('Dog');

  return (
    <div className="main-layout">
      <div className="main-content">

        {/* Top Animal Button Row */}
        <div className="animal-button-row">
          {animals.map((animal) => (
            <button
              key={animal}
              className={`animal-button ${selectedAnimal === animal ? 'active' : ''}`}
              onClick={() => setSelectedAnimal(animal)}
            >
              {animal}
            </button>
          ))}
        </div>

        {/* Split Layout: Left = Silhouette, Right = Patient Info + List */}
        <div className="silhouette-row">
          <Silhouette selectedAnimal={selectedAnimal} />
          <div className="patient-side">
            <PatientInfo />
            <PatientList />
          </div>
        </div>

      </div>
    </div>
  );
};

export default MainPage;
