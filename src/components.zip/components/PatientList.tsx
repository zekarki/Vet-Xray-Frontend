import React, { useEffect, useState } from 'react';
import './PatientList.css';

interface Patient {
  patient_id: string;
  name: string;
  owner: string;
  date_of_birth: string;
  sex: string;
  age: number;
  species: string;
  breed: string;
  owner_phone: string;
  chip_no: string;
}

const PatientList: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([]);

  useEffect(() => {
    const fetchPatients = async () => {
      try {
        const response = await fetch("http://localhost:8000/patient/", {
          method: 'GET',
          credentials: 'include',
        });
        const data = await response.json();
        if (response.ok && data.patients) {
          setPatients(data.patients);
        } else {
          console.error("Fetch error:", data.error || "Unknown error");
        }
      } catch (error) {
        console.error("Failed to fetch patients:", error);
      }
    };

    fetchPatients();
  }, []);

  return (
  <div className="patient-list-container">
    <h3>Saved Patients</h3>
    <div className="patient-list-scroll">
      {patients.length === 0 ? (
        <p style={{ color: '#888' }}>No patients found.</p>
      ) : (
        patients.map((patient) => (
          <div key={patient.patient_id} className="patient-row">
            <p><strong>{patient.name}</strong> (ID: {patient.patient_id})</p>
            <p>Sex: {patient.sex} | Breed: {patient.breed}</p>
            <p>Chip No: {patient.chip_no || 'N/A'}</p>
            <p>DOB: {patient.date_of_birth} | Species: {patient.species}</p>
            <p>Owner: {patient.owner} | Phone: {patient.owner_phone}</p>
          </div>
        ))
      )}
    </div>
  </div>
);

};

export default PatientList;
