import React, { useState } from 'react';
import './Silhouette.css';

interface SilhouetteProps {
  selectedAnimal: string;
}

const Silhouette: React.FC<SilhouetteProps> = ({ selectedAnimal }) => {
  const [hoveredPart, setHoveredPart] = useState<string | null>(null);
  const [selectedPart, setSelectedPart] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [scannedPart, setScannedPart] = useState<string | null>(null);

  const getAnimalImage = () => {
    switch (selectedAnimal.toLowerCase()) {
      case 'dog': return '/dog.png';
      case 'cat': return '/cat.png';
      case 'horse': return '/horse.png';
      case 'rabbit': return '/rabbit.png';
      default: return '';
    }
  };

  const parts = ['tail', 'torso', 'head', 'back-leg', 'front-leg'];

  const handleStartScan = () => {
    if (!selectedPart) return;

    setScanning(true);
    setScannedPart(null);

    setTimeout(() => {
      setScanning(false);
      setScannedPart(selectedPart);
    }, 2000);
  };

  return (
    <div className="silhouette-side">
      <div className="silhouette-display">
        <div className="silhouette-wrapper">
          <img
            src={getAnimalImage()}
            alt={`${selectedAnimal} silhouette`}
            className={`animal-silhouette ${selectedAnimal.toLowerCase()}`}
          />

          {parts.map((part) => (
            <div
              key={part}
              className={`highlight-zone ${part} 
                ${hoveredPart === part ? 'hovered' : ''} 
                ${selectedPart === part ? 'selected' : ''}`}
              onMouseEnter={() => setHoveredPart(part)}
              onMouseLeave={() => setHoveredPart(null)}
              onClick={() => setSelectedPart(part)}
            />
          ))}

          {hoveredPart && (
            <div className="hover-label">
              {hoveredPart.replace('-', ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
            </div>
          )}
        </div>
      </div>

      <div className="scan-button-container">
        <button
          className="start-scan-button"
          onClick={handleStartScan}
          disabled={!selectedPart || scanning}
        >
          Start Scan
        </button>
      </div>

      {scanning && (
        <div className="scan-popup">
          <div className="scan-content">
            <div className="spinner" />
            <p>Starting scan...</p>
          </div>
        </div>
      )}

      {scannedPart && (
        <div className="xray-image-container">
          <button className="close-xray-button" onClick={() => setScannedPart(null)}>×</button>
          <img
            src={`/xrays/${selectedAnimal.toLowerCase()}_${scannedPart.replace('-', '')}.png`}
            onError={(e) => (e.currentTarget.src = '/xrays/placeholder.png')}
            alt="X-ray result"
            className="xray-image"
          />
        </div>
      )}
    </div>
  );
};

export default Silhouette;
